/* 
 * File:   main.cpp testing
 * Author: Louidor Richemond 46091
 * Purpose: Homework problem 11, Diamond pattern
 * Gadis 7ed http://www.m5zn.com/newuploads/2013/11/06/pdf/978d5f9ac9d682d.pdf
 * Created on June 28, 2015, 1:45 PM
 */

//System Libraries
#include <iostream> //I/O Library
using namespace std;//Namespace for iostream

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) 
{
    //Displaying diamond patterns
    cout <<"\t   *\n\t  ***\n\t *****\n\t*******"
         <<"\n\t *****\n\t  ***\n\t   *";

    
    return 0;
}